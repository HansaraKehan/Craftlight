package ai.storyteller.lightcraft;

import android.app.NativeActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * NativeActivity that runs full screen, asks once for "All files access" (so the built-in file
 * browser can see photos), opens web links, and receives photos other apps open or share with us.
 */
public class LightCraftActivity extends NativeActivity {
    private final ConcurrentLinkedQueue<String> opened = new ConcurrentLinkedQueue<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        getWindow().setAttributes(params);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        askForFilesAccessOnce();
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    /** Called from Rust: the next photo another app opened with us (a file path), or "". */
    public String pollOpen() {
        String path = opened.poll();
        return path == null ? "" : path;
    }

    /** Called from Rust: open a web link in the user's browser. */
    public void openLink(final String url) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    // No browser installed: nothing to open.
                }
            }
        });
    }

    private void askForFilesAccessOnce() {
        if (Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()) return;
        SharedPreferences prefs = getSharedPreferences("lightcraft", Context.MODE_PRIVATE);
        if (prefs.getBoolean("asked_files_access", false)) return;
        prefs.edit().putBoolean("asked_files_access", true).apply();
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            // No settings page for it on this device: the app still runs.
        }
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        Uri found = null;
        if (Intent.ACTION_VIEW.equals(action)) {
            found = intent.getData();
            intent.setData(null);
        } else if (Intent.ACTION_SEND.equals(action)) {
            found = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
            intent.removeExtra(Intent.EXTRA_STREAM);
        }
        if (found == null) return;
        final Uri uri = found;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String path = importPhoto(uri);
                    if (path != null) opened.add(path);
                } catch (Exception e) {
                    // The photo could not be read; nothing is imported.
                }
            }
        }).start();
    }

    /** Copy the photo into the app's own folder (it is imported from there) and return its path. */
    private String importPhoto(Uri uri) throws Exception {
        if ("file".equals(uri.getScheme()) && uri.getPath() != null && new File(uri.getPath()).canRead()) {
            return uri.getPath();
        }
        String name = "photo.jpg";
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = getContentResolver().query(uri, new String[] {OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        String shown = cursor.getString(0);
                        if (shown != null && !shown.isEmpty()) name = shown;
                    }
                } finally {
                    cursor.close();
                }
            }
        } else if (uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
        }
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        File base = getExternalFilesDir(null);
        File dir = new File(base != null ? base : getCacheDir(), "incoming");
        dir.mkdirs();
        File out = uniqueFile(dir, name);
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) return null;
        try {
            OutputStream os = new FileOutputStream(out);
            try {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) > 0) os.write(buffer, 0, n);
            } finally {
                os.close();
            }
        } finally {
            in.close();
        }
        return out.getAbsolutePath();
    }

    private static File uniqueFile(File dir, String name) {
        File file = new File(dir, name);
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; file.exists(); i++) file = new File(dir, stem + " (" + i + ")" + ext);
        return file;
    }
}

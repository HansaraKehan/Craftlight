package ai.storyteller.lightcraft;

import android.app.NativeActivity;
import org.json.JSONObject;
import org.json.JSONArray;
import java.net.URL;
import java.net.HttpURLConnection;
import android.content.pm.PackageInfo;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.content.ClipData;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * NativeActivity that runs full screen, asks once for "All files access" (so the built-in file
 * browser can see photos), opens web links, and receives photos other apps open or share with us.
 */
public class LightCraftActivity extends NativeActivity {
    private static final int REQ_PICK = 4711;
    private final ConcurrentLinkedQueue<String> opened = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<String> updates = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<String> picked = new ConcurrentLinkedQueue<>();
    private boolean pickFolder;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        getWindow().setAttributes(params);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        askForFilesAccessOnce();
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    /** Called from Rust: the next photo another app opened with us (a file path), or "". */
    public String pollOpen() {
        String path = opened.poll();
        return path == null ? "" : path;
    }

    /** Called from Rust: the answer of the file picker ("CANCEL" or "OK" plus one path per line), or "". */
    public String pollPick() {
        String answer = picked.poll();
        return answer == null ? "" : answer;
    }

    /** Called from Rust: show Android's own file picker (photos, or a folder). */
    public void startPick(final boolean folder, final boolean multiple) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    pickFolder = folder;
                    Intent intent;
                    if (folder) {
                        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    } else {
                        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("*/*");
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*", "application/octet-stream"});
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
                    }
                    startActivityForResult(intent, REQ_PICK);
                } catch (Exception e) {
                    picked.add("CANCEL");
                }
            }
        });
    }

    @Override protected void onActivityResult(int request, int result, final Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQ_PICK) return;
        if (result != RESULT_OK || data == null) {
            picked.add("CANCEL");
            return;
        }
        final boolean folder = pickFolder;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    StringBuilder answer = new StringBuilder("OK");
                    if (folder) {
                        String path = data.getData() == null ? null
                            : pathFromDocId(DocumentsContract.getTreeDocumentId(data.getData()));
                        if (path == null) {
                            picked.add("CANCEL");
                            return;
                        }
                        answer.append('\n').append(path);
                    } else {
                        java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
                        ClipData clip = data.getClipData();
                        if (clip != null) {
                            for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
                        } else if (data.getData() != null) {
                            uris.add(data.getData());
                        }
                        for (Uri uri : uris) {
                            String path = importPhoto(uri);
                            if (path != null) answer.append('\n').append(path);
                        }
                    }
                    picked.add(answer.toString());
                } catch (Exception e) {
                    picked.add("CANCEL");
                }
            }
        }).start();
    }

    /** "primary:DCIM/Camera" -> /storage/emulated/0/DCIM/Camera (other volumes: /storage/<id>/...). */
    private static String pathFromDocId(String id) {
        if (id == null) return null;
        int colon = id.indexOf(':');
        if (colon < 0) return null;
        String volume = id.substring(0, colon);
        String rest = id.substring(colon + 1);
        String base = "primary".equals(volume) ? "/storage/emulated/0" : "/storage/" + volume;
        return rest.isEmpty() ? base : base + "/" + rest;
    }

    /** The file's real path when it lives on shared storage and we may read it; photos are used in place. */
    private String realPath(Uri uri) {
        if (Build.VERSION.SDK_INT < 30 || !Environment.isExternalStorageManager()) return null;
        if (!"content".equals(uri.getScheme()) || !"com.android.externalstorage.documents".equals(uri.getAuthority())) return null;
        try {
            String path = pathFromDocId(DocumentsContract.getDocumentId(uri));
            return path != null && new File(path).canRead() ? path : null;
        } catch (Exception e) {
            return null;
        }
    }

    /** Called from Rust: the version of the installed app (the release it was built as). */
    public String installedVersion() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return info.versionName == null ? "" : info.versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** Called from Rust: look up the newest release of a GitHub repository. */
    public void startUpdateCheck(final String repo) {
        new Thread(new Runnable() {
            @Override public void run() {
                HttpURLConnection connection = null;
                try {
                    connection = (HttpURLConnection) new URL("https://api.github.com/repos/" + repo + "/releases/latest").openConnection();
                    connection.setRequestProperty("Accept", "application/vnd.github+json");
                    connection.setRequestProperty("User-Agent", "LightCraft-Android");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    if (connection.getResponseCode() != 200) {
                        updates.add("NONE");
                        return;
                    }
                    InputStream in = connection.getInputStream();
                    java.io.ByteArrayOutputStream body = new java.io.ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) > 0 && body.size() < 512 * 1024) body.write(buffer, 0, n);
                    in.close();
                    JSONObject release = new JSONObject(body.toString("UTF-8"));
                    String apk = "";
                    JSONArray assets = release.optJSONArray("assets");
                    if (assets != null) {
                        for (int i = 0; i < assets.length() && apk.isEmpty(); i++) {
                            String url = assets.getJSONObject(i).optString("browser_download_url", "");
                            if (url.endsWith(".apk")) apk = url;
                        }
                    }
                    updates.add("OK\n" + release.optString("tag_name", "") + "\n" + release.optString("html_url", "") + "\n" + apk);
                } catch (Exception e) {
                    updates.add("NONE");
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
        }).start();
    }

    /** Called from Rust: the answer of the update check ("OK" and details, or "NONE"), or "". */
    public String pollUpdate() {
        String answer = updates.poll();
        return answer == null ? "" : answer;
    }

    /** Called from Rust: open a web link in the user's browser. */
    public void openLink(final String url) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    // No browser installed: nothing to open.
                }
            }
        });
    }

    private void askForFilesAccessOnce() {
        if (Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()) return;
        SharedPreferences prefs = getSharedPreferences("lightcraft", Context.MODE_PRIVATE);
        if (prefs.getBoolean("asked_files_access", false)) return;
        prefs.edit().putBoolean("asked_files_access", true).apply();
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            // No settings page for it on this device: the app still runs.
        }
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        Uri found = null;
        if (Intent.ACTION_VIEW.equals(action)) {
            found = intent.getData();
            intent.setData(null);
        } else if (Intent.ACTION_SEND.equals(action)) {
            found = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
            intent.removeExtra(Intent.EXTRA_STREAM);
        }
        if (found == null) return;
        final Uri uri = found;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String path = importPhoto(uri);
                    if (path != null) opened.add(path);
                } catch (Exception e) {
                    // The photo could not be read; nothing is imported.
                }
            }
        }).start();
    }

    /** Copy the photo into the app's own folder (it is imported from there) and return its path. */
    private String importPhoto(Uri uri) throws Exception {
        if ("file".equals(uri.getScheme()) && uri.getPath() != null && new File(uri.getPath()).canRead()) {
            return uri.getPath();
        }
        String direct = realPath(uri);
        if (direct != null) return direct;
        String name = "photo.jpg";
        if ("content".equals(uri.getScheme())) {
            Cursor cursor = getContentResolver().query(uri, new String[] {OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        String shown = cursor.getString(0);
                        if (shown != null && !shown.isEmpty()) name = shown;
                    }
                } finally {
                    cursor.close();
                }
            }
        } else if (uri.getLastPathSegment() != null) {
            name = uri.getLastPathSegment();
        }
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        File base = getExternalFilesDir(null);
        File dir = new File(base != null ? base : getCacheDir(), "incoming");
        dir.mkdirs();
        File out = uniqueFile(dir, name);
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) return null;
        try {
            OutputStream os = new FileOutputStream(out);
            try {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) > 0) os.write(buffer, 0, n);
            } finally {
                os.close();
            }
        } finally {
            in.close();
        }
        return out.getAbsolutePath();
    }

    private static File uniqueFile(File dir, String name) {
        File file = new File(dir, name);
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; file.exists(); i++) file = new File(dir, stem + " (" + i + ")" + ext);
        return file;
    }
}

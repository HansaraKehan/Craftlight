//! A touch-friendly file browser drawn over the app. It answers LightCraft's file dialogs
//! (import photos, choose a folder, save an export) because Android has no desktop dialog to call.
//! It needs "All files access" to see shared storage; the activity asks for it on first start.

use std::collections::BTreeSet;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex, mpsc};

use android_activity::AndroidApp;
use lightcraft_ui_egui::pick::{PickKind, PickRequest, Picker};

pub type Shared = Arc<Mutex<Option<Pending>>>;

static LAST_DIR: Mutex<Option<PathBuf>> = Mutex::new(None);
/// The answer channel of a dialog that is open in Android's own file picker.
static EXTERNAL: Mutex<Option<mpsc::Sender<Vec<String>>>> = Mutex::new(None);

struct Entry {
    name: String,
    path: PathBuf,
    is_dir: bool,
}

pub struct Pending {
    request: PickRequest,
    tx: mpsc::Sender<Vec<String>>,
    dir: PathBuf,
    entries: Vec<Entry>,
    chosen: BTreeSet<PathBuf>,
    name: String,
    hidden: bool,
}

/// The `Services::picker` hook. Photos and folders are chosen in Android's own file picker (it has
/// thumbnails, Google Photos and SD cards); saving, and any failure to open it, uses the built-in browser.
pub fn picker(shared: Shared, ctx: egui::Context, android: AndroidApp) -> Picker {
    Box::new(move |request: PickRequest| {
        let (tx, rx) = mpsc::channel();
        if request.kind != PickKind::Save && crate::start_pick(&android, request.kind == PickKind::Folder, request.kind == PickKind::Files) {
            *EXTERNAL.lock().map_err(|e| e.to_string())? = Some(tx);
            return Ok(rx);
        }
        let dir = start_dir();
        let name = request.file_name.clone().unwrap_or_default();
        let entries = load(&dir, &request, false);
        let pending = Pending { request, tx, dir, entries, chosen: BTreeSet::new(), name, hidden: false };
        *shared.lock().map_err(|e| e.to_string())? = Some(pending);
        ctx.request_repaint();
        Ok(rx)
    })
}

/// Android's file picker finished: answer the dialog (an empty list means cancelled).
pub fn finish_external(paths: Vec<String>) {
    if let Ok(mut waiting) = EXTERNAL.lock()
        && let Some(tx) = waiting.take()
    {
        let _ = tx.send(paths);
    }
}

fn start_dir() -> PathBuf {
    if let Ok(last) = LAST_DIR.lock()
        && let Some(dir) = last.as_ref()
        && dir.is_dir()
    {
        return dir.clone();
    }
    for candidate in ["/storage/emulated/0/DCIM", "/storage/emulated/0/Pictures", "/storage/emulated/0"] {
        let path = PathBuf::from(candidate);
        if path.is_dir() {
            return path;
        }
    }
    PathBuf::from("/")
}

fn load(dir: &Path, request: &PickRequest, hidden: bool) -> Vec<Entry> {
    let mut out = Vec::new();
    if let Ok(read) = std::fs::read_dir(dir) {
        for item in read.flatten() {
            let name = item.file_name().to_string_lossy().into_owned();
            if !hidden && name.starts_with('.') {
                continue;
            }
            let path = item.path();
            let is_dir = item.file_type().map(|t| t.is_dir()).unwrap_or_else(|_| path.is_dir());
            if !is_dir {
                if request.kind == PickKind::Folder {
                    continue;
                }
                if let Some((_, exts)) = &request.filter {
                    let ext = path.extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default();
                    if !exts.iter().any(|e| e.eq_ignore_ascii_case(&ext)) {
                        continue;
                    }
                }
            }
            out.push(Entry { name, path, is_dir });
        }
    }
    out.sort_by(|a, b| b.is_dir.cmp(&a.is_dir).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase())));
    out
}

fn roots() -> Vec<(&'static str, PathBuf)> {
    [
        ("Storage", "/storage/emulated/0"),
        ("DCIM", "/storage/emulated/0/DCIM"),
        ("Pictures", "/storage/emulated/0/Pictures"),
        ("Download", "/storage/emulated/0/Download"),
    ]
    .into_iter()
    .map(|(label, path)| (label, PathBuf::from(path)))
    .filter(|(_, path)| path.is_dir())
    .collect()
}

/// Draw the browser (when a dialog is pending) over everything else.
pub fn show(ctx: &egui::Context, shared: &Shared) {
    let Ok(mut guard) = shared.lock() else { return };
    let Some(p) = guard.as_mut() else { return };
    let rect = ctx.content_rect();
    let mut answer: Option<Vec<String>> = None;
    let mut go: Option<PathBuf> = None;
    egui::Area::new(egui::Id::new("lightcraft-android-browser")).order(egui::Order::Foreground).fixed_pos(rect.min).show(ctx, |ui| {
        egui::Frame::popup(ui.style()).show(ui, |ui| {
            ui.set_min_size(rect.size() - egui::vec2(24.0, 24.0));
            ui.heading(p.request.title.clone().unwrap_or_else(|| "Choose".to_string()));
            ui.horizontal_wrapped(|ui| {
                if ui.add(egui::Button::new("Up").min_size(egui::vec2(64.0, 40.0))).clicked() {
                    go = p.dir.parent().map(Path::to_path_buf);
                }
                for (label, path) in roots() {
                    if ui.add(egui::Button::new(label).min_size(egui::vec2(64.0, 40.0))).clicked() {
                        go = Some(path);
                    }
                }
                if ui.checkbox(&mut p.hidden, "Hidden").changed() {
                    go = Some(p.dir.clone());
                }
            });
            ui.label(p.dir.display().to_string());
            ui.separator();
            let list_height = (ui.available_height() - 130.0).max(140.0);
            egui::ScrollArea::vertical().max_height(list_height).auto_shrink([false, false]).show(ui, |ui| {
                let kind = p.request.kind;
                for entry in &p.entries {
                    let width = ui.available_width();
                    if entry.is_dir {
                        let label = format!("{}/", entry.name);
                        if ui.add(egui::Button::new(label).min_size(egui::vec2(width, 44.0))).clicked() {
                            go = Some(entry.path.clone());
                        }
                    } else {
                        let on = p.chosen.contains(&entry.path) || (kind == PickKind::Save && p.name == entry.name);
                        if ui.add(egui::Button::new(entry.name.clone()).selected(on).min_size(egui::vec2(width, 44.0))).clicked() {
                            match kind {
                                PickKind::Save => p.name = entry.name.clone(),
                                PickKind::File => {
                                    p.chosen.clear();
                                    p.chosen.insert(entry.path.clone());
                                }
                                _ => {
                                    if !p.chosen.remove(&entry.path) {
                                        p.chosen.insert(entry.path.clone());
                                    }
                                }
                            }
                        }
                    }
                }
            });
            ui.separator();
            if p.request.kind == PickKind::Save {
                ui.horizontal(|ui| {
                    ui.label("Name");
                    ui.text_edit_singleline(&mut p.name);
                });
            }
            ui.horizontal(|ui| {
                if ui.add(egui::Button::new("Cancel").min_size(egui::vec2(120.0, 44.0))).clicked() {
                    answer = Some(Vec::new());
                }
                let (label, enabled) = match p.request.kind {
                    PickKind::Folder => ("Use this folder".to_string(), true),
                    PickKind::Save => ("Save here".to_string(), !p.name.trim().is_empty()),
                    _ => (format!("Open ({})", p.chosen.len()), !p.chosen.is_empty()),
                };
                if ui.add_enabled(enabled, egui::Button::new(label).min_size(egui::vec2(180.0, 44.0))).clicked() {
                    answer = Some(match p.request.kind {
                        PickKind::Folder => vec![p.dir.to_string_lossy().into_owned()],
                        PickKind::Save => {
                            let mut name = p.name.trim().to_string();
                            if Path::new(&name).extension().is_none()
                                && let Some((_, exts)) = &p.request.filter
                                && let Some(ext) = exts.first()
                            {
                                name.push('.');
                                name.push_str(ext);
                            }
                            vec![p.dir.join(name).to_string_lossy().into_owned()]
                        }
                        _ => p.chosen.iter().map(|c| c.to_string_lossy().into_owned()).collect(),
                    });
                }
            });
        });
    });
    if let Some(dir) = go {
        p.entries = load(&dir, &p.request, p.hidden);
        p.dir = dir;
        p.chosen.clear();
    }
    if let Some(paths) = answer
        && let Some(done) = guard.take()
    {
        if let Ok(mut last) = LAST_DIR.lock() {
            *last = Some(done.dir.clone());
        }
        let _ = done.tx.send(paths);
        ctx.request_repaint();
    }
}

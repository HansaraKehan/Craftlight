//! LightCraft for Android: runs the shared egui UI (`lightcraft-ui-egui`) inside a NativeActivity.
//!
//! - Settings live in the app's private folder; the library in the app's folder on shared storage.
//! - File dialogs use the built-in browser in `browser.rs` (needs "All files access").
//! - Links open in the browser through the Java activity; photos other apps open with LightCraft
//!   (or share to it) are copied by the activity and imported here.
//! - Not yet: remembered window/UI state, AI masks and denoise, HEIC.
#![cfg(target_os = "android")]

mod browser;

use std::sync::{Arc, Mutex};
use std::time::Duration;

use android_activity::AndroidApp;
use jni::{
    JNIEnv, JavaVM,
    objects::{JObject, JString, JValue},
};
use lightcraft_engine::Session;
use lightcraft_ui_egui::panels::library_problem::LibraryProblem;
use lightcraft_ui_egui::{LightcraftApp, Services};

struct App {
    light: LightcraftApp,
    android: AndroidApp,
    picks: browser::Shared,
}

impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Some(path) = poll_open(&self.android) {
            match lightcraft_ui_egui::import::start_paths(&mut self.light, vec![path]) {
                Ok(_) => self.light.ui.view = lightcraft_ui_egui::state::ViewMode::PhotoGrid,
                Err(error) => log::warn!("import from another app: {error}"),
            }
        }
        self.light.logic(ctx);
        // Wake now and then to see a photo another app handed us.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn raw_input_hook(&mut self, _ctx: &egui::Context, raw: &mut egui::RawInput) {
        self.light.raw_input_hook(raw);
    }
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.light.ui(ui);
        browser::show(ui.ctx(), &self.picks);
        open_links(ui.ctx(), &self.android);
    }
}

/// Run `f` on the Java activity from this thread.
#[allow(unsafe_code)]
fn with_activity<R>(app: &AndroidApp, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> jni::errors::Result<R>) -> Option<R> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    match env.with_local_frame(16, |env| f(env, &activity)) {
        Ok(value) => Some(value),
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

/// The next photo another app opened with us (a file path), if any.
fn poll_open(app: &AndroidApp) -> Option<String> {
    let path = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollOpen", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let path: String = env.get_string(&text)?.into();
        Ok(path)
    })?;
    (!path.is_empty()).then_some(path)
}

/// Open a web link in the user's browser.
fn open_link(app: &AndroidApp, url: &str) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(url)?;
        env.call_method(activity, "openLink", "(Ljava/lang/String;)V", &[JValue::from(&text)])?;
        Ok(())
    })
    .is_some()
}

/// Links drawn with `ui.link` / hyperlinks ask egui to open them; do that here.
fn open_links(ctx: &egui::Context, app: &AndroidApp) {
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::OpenUrl(open) => {
                open_link(app, &open.url);
                false
            }
            _ => true,
        });
    });
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("LightCraft").with_max_level(log::LevelFilter::Info));
    let private = app.internal_data_path();
    let library_parent = app.external_data_path().or_else(|| private.clone());
    // SAFETY: nothing else has started threads that read the environment yet.
    unsafe {
        if std::env::var_os("HOME").is_none() {
            std::env::set_var("HOME", "/storage/emulated/0");
        }
        if let Some(dir) = &private {
            std::env::set_var("LIGHTCRAFT_CONFIG_DIR", dir.join("config"));
        }
    }
    let android = app.clone();
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "LightCraft",
        options,
        Box::new(move |cc| {
            let picks: browser::Shared = Arc::new(Mutex::new(None));
            let opener = android.clone();
            let services = Services {
                picker: Some(browser::picker(picks.clone(), cc.egui_ctx.clone())),
                open_url: Some(Box::new(move |url: &str| {
                    if !url.starts_with("https://") {
                        return Err("only https links are opened".to_string());
                    }
                    if open_link(&opener, url) { Ok(()) } else { Err("no app could open the link".to_string()) }
                })),
                // atomic (temp file + sync + rename), like the desktop app
                write_shared: Some(Arc::new(lightcraft_engine::export::write_file)),
                write: Some(Box::new(lightcraft_engine::export::write_file)),
                png: Some(Box::new(|img: &lightcraft_raster::Rgba8| {
                    lightcraft_codecs::encode_png(&lightcraft_codecs::EncodeImage::rgba8(img), &lightcraft_codecs::EncodeMeta::default()).unwrap_or_default()
                })),
                ..Default::default()
            };
            let mut session = Session::new().with_fs().with_system_clock();
            let mut problem = None;
            match library_parent.as_ref().map(|parent| parent.join("LightCraft Library")) {
                Some(dir) => {
                    if let Err(error) = session.open_library(&dir, false) {
                        log::error!("can't open library {}: {error}", dir.display());
                        problem = Some(LibraryProblem::new(dir.to_string_lossy(), error.to_string()));
                    }
                }
                None => problem = Some(LibraryProblem::new("", "There is no folder to keep the library in. Choose a folder for it.")),
            }
            let empty = session.catalog.is_empty();
            let mut light = LightcraftApp::new(session, services);
            lightcraft_ui_egui::i18n::set_language(light.ui.language);
            match problem {
                Some(problem) => light.library_problem = Some(problem),
                None if empty => lightcraft_ui_egui::panels::empty_library::open_on_empty_library(&mut light),
                None => {}
            }
            Ok(Box::new(App { light, android, picks }))
        }),
    );
    if let Err(error) = result {
        log::error!("LightCraft failed to start: {error}");
    }
}

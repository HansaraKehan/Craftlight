//! LightCraft for Android: runs the shared egui UI (`lightcraft-ui-egui`) inside a NativeActivity.
//!
//! - Settings live in the app's private folder; the library in the app's folder on shared storage.
//! - Photos and folders are chosen in Android's own file picker (through the Java activity); saving
//!   uses the built-in browser in `browser.rs`. Both want "All files access".
//! - Links open in the browser through the Java activity; photos other apps open with LightCraft
//!   (or share to it) are copied by the activity and imported here.
//! - AI masks, AI denoise and HEIC are on unless the `ai` feature is switched off.
#![cfg(target_os = "android")]

mod browser;

use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use android_activity::AndroidApp;
use jni::{
    JNIEnv, JavaVM,
    objects::{JObject, JString, JValue},
};
use lightcraft_engine::Session;
use lightcraft_ui_egui::panels::library_problem::LibraryProblem;
use lightcraft_ui_egui::{LightcraftApp, Services, UiState};

struct App {
    light: LightcraftApp,
    android: AndroidApp,
    picks: browser::Shared,
    /// `<config>/ui.json`, the last bytes written to it, when we last looked, and whether it is safe to overwrite.
    prefs_path: Option<PathBuf>,
    saved: Vec<u8>,
    last_check: Instant,
    prefs_ok: bool,
}

impl App {
    /// Remember interface settings between launches (written at most every few seconds, only when changed).
    fn save_prefs(&mut self) {
        if !self.prefs_ok || self.last_check.elapsed() < Duration::from_secs(5) {
            return;
        }
        self.last_check = Instant::now();
        let Some(path) = &self.prefs_path else { return };
        let Ok(bytes) = serde_json::to_vec_pretty(&self.light.ui) else { return };
        if bytes != self.saved {
            if let Some(dir) = path.parent() {
                let _ = std::fs::create_dir_all(dir);
            }
            if lightcraft_engine::export::write_file(&path.to_string_lossy(), &bytes).is_ok() {
                self.saved = bytes;
            }
        }
    }
}

/// The saved settings, if the file is there and readable; `Err` means "leave the file alone".
fn load_prefs(path: &std::path::Path) -> Result<Option<UiState>, ()> {
    let bytes = match std::fs::read(path) {
        Ok(bytes) => bytes,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(_) => return Err(()),
    };
    let mut value: serde_json::Value = serde_json::from_slice(&bytes).map_err(|_| ())?;
    if let Ok(ui) = serde_json::from_value::<UiState>(value.clone()) {
        return Ok(Some(ui.sanitized()));
    }
    // A panel layout that no longer fits: drop only that, keep the other settings.
    if let Some(fields) = value.as_object_mut() {
        fields.remove("docking");
    }
    serde_json::from_value::<UiState>(value).map(|ui| Some(ui.sanitized())).map_err(|_| ())
}

impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Some(path) = poll_open(&self.android) {
            match lightcraft_ui_egui::import::start_paths(&mut self.light, vec![path]) {
                Ok(_) => self.light.ui.view = lightcraft_ui_egui::state::ViewMode::PhotoGrid,
                Err(error) => log::warn!("import from another app: {error}"),
            }
        }
        if let Some(answer) = poll_pick(&self.android) {
            browser::finish_external(answer);
        }
        self.light.logic(ctx);
        self.save_prefs();
        // Wake now and then to see a photo another app handed us, or a file picker answer.
        ctx.request_repaint_after(Duration::from_millis(700));
    }
    fn raw_input_hook(&mut self, _ctx: &egui::Context, raw: &mut egui::RawInput) {
        self.light.raw_input_hook(raw);
    }
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.light.ui(ui);
        browser::show(ui.ctx(), &self.picks);
        open_links(ui.ctx(), &self.android);
    }
}

/// Run `f` on the Java activity from this thread.
#[allow(unsafe_code)]
fn with_activity<R>(app: &AndroidApp, f: impl FnOnce(&mut JNIEnv<'_>, &JObject<'_>) -> jni::errors::Result<R>) -> Option<R> {
    // SAFETY: android_main is called with the VM owned by Android for this process.
    let vm = unsafe { JavaVM::from_raw(app.vm_as_ptr().cast()) }.ok()?;
    let mut env = vm.attach_current_thread().ok()?;
    // SAFETY: AndroidApp keeps this global reference to the activity alive; we only borrow it.
    let activity = unsafe { JObject::from_raw(app.activity_as_ptr().cast()) };
    match env.with_local_frame(16, |env| f(env, &activity)) {
        Ok(value) => Some(value),
        Err(_) => {
            let _ = env.exception_clear();
            None
        }
    }
}

/// The next photo another app opened with us (a file path), if any.
fn poll_open(app: &AndroidApp) -> Option<String> {
    let path = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollOpen", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let path: String = env.get_string(&text)?.into();
        Ok(path)
    })?;
    (!path.is_empty()).then_some(path)
}

/// The answer of Android's file picker, once it has closed: the chosen paths (none = cancelled).
fn poll_pick(app: &AndroidApp) -> Option<Vec<String>> {
    let answer = with_activity(app, |env, activity| {
        let value = env.call_method(activity, "pollPick", "()Ljava/lang/String;", &[])?;
        let text = JString::from(value.l()?);
        let answer: String = env.get_string(&text)?.into();
        Ok(answer)
    })?;
    if answer.is_empty() {
        return None;
    }
    Some(answer.strip_prefix("OK\n").map(|paths| paths.split('\n').filter(|p| !p.is_empty()).map(str::to_string).collect()).unwrap_or_default())
}

/// Open Android's file picker (photos, or a folder). `false` means it could not be opened.
pub(crate) fn start_pick(app: &AndroidApp, folder: bool, multiple: bool) -> bool {
    with_activity(app, |env, activity| {
        env.call_method(activity, "startPick", "(ZZ)V", &[JValue::Bool(u8::from(folder)), JValue::Bool(u8::from(multiple))])?;
        Ok(())
    })
    .is_some()
}

/// Open a web link in the user's browser.
fn open_link(app: &AndroidApp, url: &str) -> bool {
    with_activity(app, |env, activity| {
        let text = env.new_string(url)?;
        env.call_method(activity, "openLink", "(Ljava/lang/String;)V", &[JValue::from(&text)])?;
        Ok(())
    })
    .is_some()
}

/// Links drawn with `ui.link` / hyperlinks ask egui to open them; do that here.
fn open_links(ctx: &egui::Context, app: &AndroidApp) {
    ctx.output_mut(|output| {
        output.commands.retain(|command| match command {
            egui::OutputCommand::OpenUrl(open) => {
                open_link(app, &open.url);
                false
            }
            _ => true,
        });
    });
}

// SAFETY: android-activity looks up this single, uniquely named entry point.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("LightCraft").with_max_level(log::LevelFilter::Info));
    let private = app.internal_data_path();
    let library_parent = app.external_data_path().or_else(|| private.clone());
    // SAFETY: nothing else has started threads that read the environment yet.
    unsafe {
        if std::env::var_os("HOME").is_none() {
            std::env::set_var("HOME", "/storage/emulated/0");
        }
        if let Some(dir) = &private {
            std::env::set_var("LIGHTCRAFT_CONFIG_DIR", dir.join("config"));
        }
    }
    let android = app.clone();
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "LightCraft",
        options,
        Box::new(move |cc| {
            let picks: browser::Shared = Arc::new(Mutex::new(None));
            let opener = android.clone();
            let services = Services {
                picker: Some(browser::picker(picks.clone(), cc.egui_ctx.clone(), android.clone())),
                open_url: Some(Box::new(move |url: &str| {
                    if !url.starts_with("https://") {
                        return Err("only https links are opened".to_string());
                    }
                    if open_link(&opener, url) { Ok(()) } else { Err("no app could open the link".to_string()) }
                })),
                // atomic (temp file + sync + rename), like the desktop app
                write_shared: Some(Arc::new(lightcraft_engine::export::write_file)),
                write: Some(Box::new(lightcraft_engine::export::write_file)),
                png: Some(Box::new(|img: &lightcraft_raster::Rgba8| {
                    lightcraft_codecs::encode_png(&lightcraft_codecs::EncodeImage::rgba8(img), &lightcraft_codecs::EncodeMeta::default()).unwrap_or_default()
                })),
                ..Default::default()
            };
            let mut session = Session::new().with_fs().with_system_clock().with_default_denoise_models().with_default_face_models().with_default_slide_templates();
            // AI masks: the SAM 3 checkpoint is looked for in <config>/models/sam3, or offered as a download.
            #[cfg(feature = "ai")]
            {
                session = session.with_default_sam3_model();
            }
            let mut problem = None;
            match library_parent.as_ref().map(|parent| parent.join("LightCraft Library")) {
                Some(dir) => {
                    if let Err(error) = session.open_library(&dir, false) {
                        log::error!("can't open library {}: {error}", dir.display());
                        problem = Some(LibraryProblem::new(dir.to_string_lossy(), error.to_string()));
                    }
                }
                None => problem = Some(LibraryProblem::new("", "There is no folder to keep the library in. Choose a folder for it.")),
            }
            let empty = session.catalog.is_empty();
            let mut light = LightcraftApp::new(session, services);
            let prefs_path = lightcraft_engine::config::config_dir().map(|dir| dir.join("ui.json"));
            let mut prefs_ok = prefs_path.is_some();
            if let Some(path) = &prefs_path {
                match load_prefs(path) {
                    Ok(Some(ui)) => light.ui = ui,
                    Ok(None) => {}
                    Err(()) => {
                        log::warn!("settings in {} could not be read; they will not be overwritten", path.display());
                        prefs_ok = false;
                    }
                }
            }
            lightcraft_ui_egui::i18n::set_language(light.ui.language);
            match problem {
                Some(problem) => light.library_problem = Some(problem),
                None if empty => lightcraft_ui_egui::panels::empty_library::open_on_empty_library(&mut light),
                None => {}
            }
            Ok(Box::new(App { light, android, picks, prefs_path, saved: Vec::new(), last_check: Instant::now(), prefs_ok }))
        }),
    );
    if let Err(error) = result {
        log::error!("LightCraft failed to start: {error}");
    }
}

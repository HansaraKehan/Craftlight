## Current version

- The "library could not be locked" error message is now hidden.

Builds again against the newest upstream LightCraft, so the Android build no longer fails to compile after an upstream update.

## Current version

- A welcome window now appears on first start, explaining why LightCraft needs access to your files, with a clip-art illustration. Choose "Allow file access" to continue, or "Not now" to use the app without it.
- The "library could not be locked" error message is now hidden.

Builds again against the newest upstream LightCraft, so the Android build no longer fails to compile after an upstream update.

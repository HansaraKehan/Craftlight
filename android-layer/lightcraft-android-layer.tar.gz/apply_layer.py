#!/usr/bin/env python3
"""Add the Android layer to a LightCraft checkout. Run from the repository root."""
import os
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def patch_workspace() -> None:
    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor/winit"]' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/winit"]\n' + text[j + 1 :]
    line = 'winit = { path = "vendor/winit" }\n'
    if "[patch.crates-io]" in text:
        # Upstream already patches some crates: add ours to that table (replacing its own winit entry, if any).
        import re

        text = re.sub(r"(?m)^winit\s*=.*\n", "", text)
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + line, 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: keep winit but restore hardware mouse, wheel and keyboard events.\n[patch.crates-io]\n" + line
    cargo.write_text(text, encoding="utf-8")


def add_releases_link() -> None:
    """Help > "Get the Android app / updates..." (also in About) opens this repository's Releases page."""
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftLight"
    url = f"https://github.com/{repo}/releases"
    links = ROOT / "crates/ui-egui/src/links.rs"
    menus = ROOT / "crates/ui-egui/src/menus.rs"
    dialogs = ROOT / "crates/ui-egui/src/panels/dialogs.rs"
    done = []
    if links.exists() and menus.exists():
        lt = links.read_text(encoding="utf-8")
        mt = menus.read_text(encoding="utf-8")
        a_const = 'pub const GITHUB: &str = "https://github.com/storytold/lightcraft";'
        a_list = '    ("app.feedback", "Send Feedback…", FEEDBACK),\n];'
        a_menu = '    ("app.feedback", "Send Feedback…", None, "Help"),'
        if a_const in lt and a_list in lt and a_menu in mt and "androidReleases" not in lt:
            lt = lt.replace(a_const, a_const + f'\npub const ANDROID_RELEASES: &str = "{url}";', 1)
            lt = lt.replace(a_list, '    ("app.feedback", "Send Feedback…", FEEDBACK),\n    ("app.androidReleases", "Get the Android app / updates…", ANDROID_RELEASES),\n];', 1)
            mt = mt.replace(a_menu, a_menu + '\n    ("app.androidReleases", "Get the Android app / updates…", None, "Help"),', 1)
            links.write_text(lt, encoding="utf-8")
            menus.write_text(mt, encoding="utf-8")
            done.append("Help menu")
    if dialogs.exists():
        dt = dialogs.read_text(encoding="utf-8")
        anchor = '                                ("ArtCraft — more creative apps", crate::links::WEBSITE),'
        if anchor in dt and "ANDROID_RELEASES" not in dt and "androidReleases" in links.read_text(encoding="utf-8"):
            dt = dt.replace(anchor, anchor + '\n                                ("Get the Android app", crate::links::ANDROID_RELEASES),', 1)
            dialogs.write_text(dt, encoding="utf-8")
            done.append("About dialog")
    print("Releases link added to: " + (", ".join(done) if done else "nowhere (upstream code changed)"))


patch_workspace()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
add_releases_link()
print("Android layer applied")

#!/usr/bin/env python3
"""Add the Android layer to a LightCraft checkout. Run from the repository root."""
import os
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()


def developer_url() -> str:
    """The profile of whoever owns the repository this is built in (their GitHub account)."""
    owner = (os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/x").split("/")[0]
    return f"https://github.com/{owner}"


def fail(message: str) -> None:
    """Stop the build with a message that names what upstream changed."""
    print(f"::error::Android layer: {message}", file=sys.stderr)
    sys.exit(1)


def sub_all(path: Path, pairs: list, label: str, required: bool = False) -> None:
    """Replace text in a source file, everywhere it occurs, and say how many changes were made.

    required=True: every pair must match at least once, otherwise the build stops. Use it for any
    change the release depends on, so an upstream rewrite can never be applied silently as a no-op.
    """
    if not path.exists():
        if required:
            fail(f"{label}: {path} is missing in upstream. Update the layer for the new upstream layout.")
        print(f"{label}: skipped ({path.name} not found)")
        return
    text = path.read_text(encoding="utf-8")
    changes = 0
    for old, new in pairs:
        count = text.count(old)
        if required and count == 0:
            fail(f"{label}: this text was not found in {path.relative_to(ROOT)}, so upstream changed it:\n{old}")
        changes += count
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8")
    print(f"{label}: {changes} change(s)")


def drop_in_patch_section(text: str, names: list[str]) -> str:
    """Remove `name = ...` lines of those crates from [patch.crates-io] only (never from [workspace.dependencies])."""
    found = re.search(r"(?m)^\[patch\.crates-io\]\s*$", text)
    if not found:
        return text
    start = found.end()
    following = re.search(r"(?m)^\[", text[start:])
    end = start + following.start() if following else len(text)
    section = re.sub(r"(?m)^(" + "|".join(names) + r")\s*=.*\n", "", text[start:end])
    return text[:start] + section + text[end:]


def patch_workspace() -> None:
    cargo = ROOT / "Cargo.toml"
    text = cargo.read_text(encoding="utf-8")
    if 'exclude = ["vendor/winit"]' not in text:
        i = text.find("members = [")
        if i < 0:
            sys.exit("Cargo.toml has no workspace members line; the layer needs updating")
        j = text.index("\n", i)
        text = text[: j + 1] + 'exclude = ["vendor/winit"]\n' + text[j + 1 :]
    line = 'winit = { path = "vendor/winit" }\n'
    if "[patch.crates-io]" in text:
        # Upstream already patches some crates: add ours to that table (replacing its own winit entry, if any).
        import re

        text = drop_in_patch_section(text, ["winit"])
        text = text.replace("[patch.crates-io]\n", "[patch.crates-io]\n" + line, 1)
    else:
        text = text.rstrip("\n") + "\n\n# Android: keep winit but restore hardware mouse, wheel and keyboard events.\n[patch.crates-io]\n" + line
    if line.strip() not in text:
        fail("Cargo.toml: the winit patch line did not land; upstream changed its [patch.crates-io] layout.")
    cargo.write_text(text, encoding="utf-8")


def add_releases_link() -> None:
    """Help > "Get the Android app / updates..." (also in About) opens this repository's Releases page."""
    repo = os.environ.get("GITHUB_REPOSITORY") or "HansaraKehan/CraftLight"
    url = f"https://github.com/{repo}/releases"
    links = ROOT / "crates/ui-egui/src/links.rs"
    menus = ROOT / "crates/ui-egui/src/menus.rs"
    dialogs = ROOT / "crates/ui-egui/src/panels/dialogs.rs"
    done = []
    if links.exists() and menus.exists():
        lt = links.read_text(encoding="utf-8")
        mt = menus.read_text(encoding="utf-8")
        a_const = 'pub const GITHUB: &str = "https://github.com/storytold/lightcraft";'
        a_list = '    ("app.feedback", "Send Feedback…", FEEDBACK),\n];'
        a_menu = '    ("app.feedback", "Send Feedback…", None, "Help"),'
        if a_const in lt and a_list in lt and a_menu in mt and "androidReleases" not in lt:
            lt = lt.replace(a_const, a_const + f'\npub const ANDROID_RELEASES: &str = "{url}";', 1)
            lt = lt.replace(a_list, '    ("app.feedback", "Send Feedback…", FEEDBACK),\n    ("app.androidReleases", "Get the Android app / updates…", ANDROID_RELEASES),\n];', 1)
            mt = mt.replace(a_menu, a_menu + '\n    ("app.androidReleases", "Get the Android app / updates…", None, "Help"),', 1)
            links.write_text(lt, encoding="utf-8")
            menus.write_text(mt, encoding="utf-8")
            done.append("Help menu")
    if dialogs.exists():
        dt = dialogs.read_text(encoding="utf-8")
        anchor = '                                ("ArtCraft — more creative apps", crate::links::WEBSITE),'
        if anchor in dt and "ANDROID_RELEASES" not in dt and "androidReleases" in links.read_text(encoding="utf-8"):
            dt = dt.replace(anchor, anchor + '\n                                ("Get the Android app", crate::links::ANDROID_RELEASES),', 1)
            dialogs.write_text(dt, encoding="utf-8")
            done.append("About dialog")
    print("Releases link added to: " + (", ".join(done) if done else "nowhere (upstream code changed; optional, so the build continues)"))




def quiet_lock_warning() -> None:
    """Android's file systems may refuse the one-program-at-a-time lock on the catalog. LightCraft then opens the
    library anyway and warns about it on every start; on Android that warning is only noise, so it is not shown."""
    sub_all(
        ROOT / "crates/engine/src/library.rs",
        [("lock.filter(|l| !l.held()).map(|_| {", 'lock.filter(|l| !l.held() && !cfg!(target_os = "android")).map(|_| {')],
        "Library lock warning",
        required=True,
    )


def sub_tree(pairs: list, label: str, required: bool = True) -> None:
    """Replace text in every Rust source file of the app, wherever upstream moved it to.

    Upstream reorganises files often (a menu moved from menus.rs into menus/ui_commands.rs, say), so a
    replacement is looked for across crates/ and apps/ instead of in one named file. It only fails when
    the text is gone from the whole tree, which is the real signal that upstream changed the wording.
    """
    total = 0
    touched = []
    for path in list((ROOT / "crates").rglob("*.rs")) + list((ROOT / "apps").rglob("*.rs")):
        if "target" in path.parts or "vendor" in path.parts:
            continue
        text = path.read_text(encoding="utf-8")
        hits = 0
        for old, new in pairs:
            hits += text.count(old)
            text = text.replace(old, new)
        if hits:
            path.write_text(text, encoding="utf-8")
            total += hits
            touched.append(str(path.relative_to(ROOT)))
    if required and total == 0:
        fail(f"{label}: this text was not found anywhere in crates/ or apps/, so upstream changed it:\n{pairs[0][0]}")
    print(f"{label}: {total} change(s) in {len(touched)} file(s)")


def rebrand() -> None:
    """Replace the upstream community (Discord) link with a link to this build's developer on GitHub.
    The licences, copyright notices and the credit to the original project stay where they are."""
    url = developer_url()
    # The one link address: required, because the About and Help links use it.
    sub_all(ROOT / "crates/ui-egui/src/links.rs",
            [('pub const DISCORD: &str = "https://discord.gg/artcraft";', f'pub const DISCORD: &str = "{url}";')],
            "Community link address", required=True)
    sub_tree([('"Join the ArtCraft Discord…"', '"Follow the developer on GitHub…"'),
              ('"Join the ArtCraft Discord"', '"Follow the developer on GitHub"'),
              ('"Join the ArtCraft community on Discord"', '"Follow the developer of this Android build on GitHub"')],
             "Community link labels", required=True)


patch_workspace()
shutil.copytree(HERE / "overlay", ROOT, dirs_exist_ok=True)
add_releases_link()
rebrand()
quiet_lock_warning()
print("Android layer applied")
